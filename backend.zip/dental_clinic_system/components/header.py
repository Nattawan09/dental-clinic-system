import reflex as rx

def header() -> rx.Component:
    return rx.box(
        rx.hstack(
            # Logo / Home Link
            rx.link(
                rx.hstack(
                    rx.icon(tag="activity", color="var(--accent-9)", size=32),
                    rx.heading("SmileCare Clinic", size="6", color="var(--accent-11)"),
                    align="center",
                    spacing="3",
                ),
                href="/",
                underline="none",
            ),
            rx.spacer(),
            # Navigation Links
            rx.hstack(
                rx.link(
                    "Dental History",
                    href="/history",
                    size="3",
                    weight="medium",
                    color="var(--slate-11)",
                    _hover={"color": "var(--accent-9)"},
                ),
                rx.link(
                    rx.button(
                        "Sign In",
                        variant="solid",
                        color_scheme="cyan",
                        size="3",
                        radius="full",
                    ),
                    href="/auth",
                ),
                rx.avatar(fallback="US", color_scheme="cyan", size="3", radius="full"),
                align="center",
                spacing="5",
            ),
            width="100%",
            align="center",
            padding_x="6",
            padding_y="4",
        ),
        box_shadow="0px 2px 4px rgba(0, 0, 0, 0.05)",
        background_color="white",
        position="sticky",
        top="0",
        z_index="50",
        width="100%",
    )
