import reflex as rx
from dental_clinic_system.components import header, footer

def service_card(title: str, description: str, icon: str, color: str) -> rx.Component:
    return rx.card(
        rx.vstack(
            rx.box(
                rx.icon(tag=icon, size=40, color=color),
                padding="4",
                background_color="var(--slate-2)",
                border_radius="50%",
                margin_bottom="4",
            ),
            rx.heading(title, size="5", margin_bottom="2"),
            rx.text(description, size="2", color="var(--slate-10)", align="center"),
            align="center",
            width="100%",
        ),
        padding="6",
        width="100%",
        box_shadow="md",
        _hover={
            "transform": "translateY(-5px)",
            "box_shadow": "0px 10px 15px -3px rgba(0, 0, 0, 0.1)",
            "transition": "all 0.3s ease",
        },
    )

@rx.page(route="/", title="SmileCare - Home")
def home() -> rx.Component:
    return rx.box(
        header(),
        
        # Hero Section
        rx.box(
            rx.container(
                rx.flex(
                    rx.vstack(
                        rx.heading(
                            "Beautiful Smiles Start Here",
                            size="9",
                            weight="bold",
                            color="var(--slate-12)",
                            line_height="1.1",
                        ),
                        rx.text(
                            "Experience world-class dental care with our team of expert professionals. We bring the latest technology to ensure your smile is bright and healthy.",
                            size="4",
                            color="var(--slate-11)",
                            margin_top="4",
                            margin_bottom="6",
                        ),
                        rx.hstack(
                            rx.button("Book Appointment", size="4", color_scheme="cyan", radius="full"),
                            rx.button("Our Services", size="4", variant="soft", color_scheme="cyan", radius="full"),
                            spacing="4",
                        ),
                        align="start",
                        justify="center",
                        height="100%",
                        padding_right="8",
                    ),
                    rx.box(
                        rx.image(
                            src="https://images.unsplash.com/photo-1606811841689-23dfddce3e95?auto=format&fit=crop&q=80&w=800",
                            border_radius="xl",
                            box_shadow="xl",
                        ),
                        width="100%",
                        display="block",
                    ),
                    direction="row",
                    spacing="9",
                    padding_y="9",
                    align="center",
                ),
            ),
            background="linear-gradient(to bottom right, var(--cyan-2), var(--teal-2))",
            padding_top="12",
            padding_bottom="12",
        ),

        # Services Section
        rx.container(
            rx.vstack(
                rx.heading("Our Premium Services", size="8", margin_top="9", margin_bottom="2"),
                rx.text("Comprehensive dental care for you and your family.", size="3", color="var(--slate-10)", margin_bottom="8"),
                
                rx.grid(
                    service_card(
                        "Orthodontics",
                        "Straighten your teeth with modern braces or clear aligners for a perfect smile.",
                        "smile",
                        "var(--cyan-9)",
                    ),
                    service_card(
                        "Teeth Cleaning",
                        "Professional scaling and polishing to maintain optimal oral hygiene.",
                        "sparkles",
                        "var(--teal-9)",
                    ),
                    service_card(
                        "Teeth Whitening",
                        "Brighten your smile safely and effectively with our advanced whitening treatments.",
                        "sun",
                        "var(--amber-9)",
                    ),
                    service_card(
                        "Dental Implants",
                        "Permanent, natural-looking replacements for missing teeth.",
                        "activity",
                        "var(--blue-9)",
                    ),
                    columns="4",
                    spacing="6",
                    width="100%",
                ),
                align="center",
                margin_bottom="9",
                width="100%",
            ),
        ),
        
        footer(),
        background_color="var(--slate-1)",
        min_height="100vh",
    )
