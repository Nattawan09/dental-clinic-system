import reflex as rx
from dental_clinic_system.components import header, footer

def social_login_button(provider: str, icon_tag: str) -> rx.Component:
    return rx.button(
        rx.hstack(
            rx.icon(tag=icon_tag, size=20),
            rx.text(f"Continue with {provider}", weight="medium"),
            spacing="2",
            align="center",
        ),
        variant="outline",
        size="3",
        width="100%",
        color_scheme="gray",
        radius="large",
        margin_bottom="3",
    )

def login_form() -> rx.Component:
    return rx.vstack(
        rx.text("Welcome back! Please enter your details.", size="2", color="var(--slate-10)", margin_bottom="4"),
        
        rx.vstack(
            rx.text("Email", size="2", weight="medium"),
            rx.input(placeholder="Enter your email", type="email", width="100%", size="3"),
            spacing="1",
            width="100%",
            margin_bottom="3",
        ),
        
        rx.vstack(
            rx.text("Password", size="2", weight="medium"),
            rx.input(placeholder="••••••••", type="password", width="100%", size="3"),
            spacing="1",
            width="100%",
            margin_bottom="4",
        ),
        
        rx.button("Sign In", size="3", width="100%", color_scheme="cyan", radius="large", margin_bottom="4"),
        
        rx.hstack(
            rx.divider(width="100%"),
            rx.text("OR", size="1", color="var(--slate-9)", white_space="nowrap"),
            rx.divider(width="100%"),
            align="center",
            width="100%",
            spacing="3",
            margin_bottom="4",
        ),
        
        social_login_button("Google", "chrome"),
        social_login_button("Facebook", "facebook"),
        social_login_button("Apple", "apple"),
        
        width="100%",
        align="start",
    )

def signup_form() -> rx.Component:
    return rx.vstack(
        rx.text("Create an account to manage your appointments.", size="2", color="var(--slate-10)", margin_bottom="4"),
        
        rx.hstack(
            rx.vstack(
                rx.text("First Name", size="2", weight="medium"),
                rx.input(placeholder="John", width="100%", size="3"),
                spacing="1",
                width="100%",
            ),
            rx.vstack(
                rx.text("Last Name", size="2", weight="medium"),
                rx.input(placeholder="Doe", width="100%", size="3"),
                spacing="1",
                width="100%",
            ),
            spacing="4",
            width="100%",
            margin_bottom="3",
        ),
        
        rx.vstack(
            rx.text("Date of Birth", size="2", weight="medium"),
            rx.input(type="date", width="100%", size="3"),
            spacing="1",
            width="100%",
            margin_bottom="3",
        ),

        rx.vstack(
            rx.text("Email", size="2", weight="medium"),
            rx.input(placeholder="Enter your email", type="email", width="100%", size="3"),
            spacing="1",
            width="100%",
            margin_bottom="3",
        ),
        
        rx.vstack(
            rx.text("Password", size="2", weight="medium"),
            rx.input(placeholder="Create a password", type="password", width="100%", size="3"),
            spacing="1",
            width="100%",
            margin_bottom="5",
        ),
        
        rx.button("Create Account", size="3", width="100%", color_scheme="cyan", radius="large"),
        
        width="100%",
        align="start",
    )

@rx.page(route="/auth", title="SmileCare - Authentication")
def auth() -> rx.Component:
    return rx.box(
        header(),
        
        rx.center(
            rx.card(
                rx.vstack(
                    rx.center(
                        rx.icon(tag="activity", color="var(--accent-9)", size=40),
                        margin_bottom="4",
                        width="100%",
                    ),
                    rx.heading("SmileCare", size="7", align="center", width="100%", margin_bottom="6"),
                    
                    rx.tabs.root(
                        rx.tabs.list(
                            rx.tabs.trigger("Sign In", value="login", width="50%"),
                            rx.tabs.trigger("Sign Up", value="signup", width="50%"),
                            width="100%",
                            margin_bottom="4",
                        ),
                        rx.tabs.content(
                            login_form(),
                            value="login",
                            width="100%",
                        ),
                        rx.tabs.content(
                            signup_form(),
                            value="signup",
                            width="100%",
                        ),
                        default_value="login",
                        width="100%",
                    ),
                    width="100%",
                    padding_x="6",
                    padding_y="4",
                ),
                width="450px",
                padding="6",
                box_shadow="lg",
                margin_top="12",
                margin_bottom="12",
            ),
            width="100%",
            min_height="calc(100vh - 150px)", # subtract header roughly
            background="linear-gradient(135deg, var(--cyan-2) 0%, var(--teal-1) 100%)",
        ),
        
        footer(),
        background_color="var(--slate-1)",
    )
